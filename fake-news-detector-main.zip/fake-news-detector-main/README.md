# fake-news-detector
Fake News Detection using Machine Learning
